-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 21, 2026 at 02:01 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Skola`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `admin_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`admin_id`, `first_name`, `last_name`, `email`, `password`, `phone`) VALUES
(1, 'Super', 'Admin', 'admin@skola.edu.np', '$2a$10$6IksNL/eIUCkvalKCOQ4MOnAzuO5qFnLjVj0RucrqU6TG3jZBY6ZO', '9812345678');

-- --------------------------------------------------------

--
-- Table structure for table `Announcement`
--

CREATE TABLE `Announcement` (
  `announcement_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `genre` varchar(20) DEFAULT NULL,
  `image_path` varchar(512) DEFAULT NULL,
  `published_at` datetime NOT NULL DEFAULT current_timestamp(),
  `attachment_path` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Announcement`
--

INSERT INTO `Announcement` (`announcement_id`, `admin_id`, `title`, `content`, `genre`, `image_path`, `published_at`, `attachment_path`) VALUES
(28, 1, '123', '23', 'non-academics', NULL, '2026-05-21 03:39:01', 'uploads/sample (1).docx'),
(30, 1, 'Test1', 'This is a test announcement', 'non-academics', NULL, '2026-05-21 11:07:35', 'uploads/report (4).pdf'),
(31, 1, 'Test2', 'Test Announcement', 'non-academics', NULL, '2026-05-21 11:09:10', 'uploads/sample (1) (2).docx');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`) VALUES
(1, 'Everest'),
(2, 'Annapurna'),
(3, 'Machhapuchhre'),
(4, 'Dhaulagiri'),
(5, 'Kanchenjunga'),
(6, 'Kathmandu'),
(7, 'Pokhara'),
(8, 'Lalitpur'),
(9, 'Bhaktapur'),
(10, 'Mustang');

-- --------------------------------------------------------

--
-- Table structure for table `ClassReservation`
--

CREATE TABLE `ClassReservation` (
  `reservation_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_from` time NOT NULL,
  `time_to` time NOT NULL,
  `comment` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ClassReservation`
--

INSERT INTO `ClassReservation` (`reservation_id`, `student_id`, `class_id`, `date`, `time_from`, `time_to`, `comment`, `status`, `created_at`) VALUES
(4, 10, 9, '2026-05-22', '00:11:00', '01:11:00', '', 'Approved', '2026-05-21 00:10:29'),
(5, 10, 9, '2026-05-22', '03:18:00', '04:19:00', '', 'Approved', '2026-05-21 00:16:06'),
(6, 10, 2, '2026-05-21', '14:06:00', '15:06:00', '', 'Approved', '2026-05-21 12:05:02'),
(7, 10, 4, '2026-05-23', '15:10:00', '16:10:00', '', 'Rejected', '2026-05-21 12:09:45');

-- --------------------------------------------------------

--
-- Table structure for table `Faculty`
--

CREATE TABLE `Faculty` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `total_credits` int(11) DEFAULT NULL,
  `faculty_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Faculty`
--

INSERT INTO `Faculty` (`faculty_id`, `faculty_name`, `total_credits`, `faculty_description`) VALUES
(1, 'Bachelor of Computing', NULL, NULL),
(2, 'Bachelor of Networking', NULL, NULL),
(3, 'Bachelor of Artificial Intelligence', NULL, NULL),
(4, 'Bachelor of Accounting and Finance', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Module`
--

CREATE TABLE `Module` (
  `module_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `module_description` text DEFAULT NULL,
  `module_credits` int(11) DEFAULT NULL,
  `semester` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Module`
--

INSERT INTO `Module` (`module_id`, `faculty_id`, `module_name`, `module_description`, `module_credits`, `semester`) VALUES
(1, 1, 'Programming Fundamentals', 'Introduction to programming using Java', 15, 1),
(2, 1, 'Database Systems', 'Relational databases and SQL', 15, 1),
(3, 1, 'Web Development', 'HTML, CSS, JavaScript and server-side dev', 15, 2),
(4, 1, 'Data Structures & Algorithms', 'Core CS data structures and algorithm design', 15, 2),
(5, 1, 'Operating Systems', 'Process management, memory, file systems', 15, 3),
(6, 1, 'Software Engineering', 'SDLC, agile, design patterns', 15, 3),
(7, 1, 'Computer Networks', 'TCP/IP, routing, network security', 15, 4),
(8, 1, 'Final Year Project', 'Capstone project', 30, 4),
(9, 2, 'Network Fundamentals', 'OSI model, protocols, topologies', 15, 1),
(10, 2, 'Routing & Switching', 'Cisco IOS, VLANs, spanning tree', 15, 1),
(11, 2, 'Network Security', 'Firewalls, VPNs, intrusion detection', 15, 2),
(12, 2, 'Wireless Networks', 'WiFi standards, mobile networking', 15, 2),
(13, 2, 'Cloud Infrastructure', 'AWS, Azure, virtualisation', 15, 3),
(14, 2, 'Network Administration', 'Linux server admin, DNS, DHCP', 15, 3),
(15, 2, 'Ethical Hacking', 'Penetration testing fundamentals', 15, 4),
(16, 2, 'Final Year Project', 'Capstone project', 30, 4),
(17, 3, 'Mathematics for AI', 'Linear algebra, calculus, probability', 15, 1),
(18, 3, 'Python Programming', 'Python for data science and AI', 15, 1),
(19, 3, 'Machine Learning', 'Supervised and unsupervised learning', 15, 2),
(20, 3, 'Deep Learning', 'Neural networks, CNNs, RNNs', 15, 2),
(21, 3, 'Natural Language Processing', 'Text processing, transformers, LLMs', 15, 3),
(22, 3, 'Computer Vision', 'Image processing, object detection', 15, 3),
(23, 3, 'AI Ethics & Governance', 'Responsible AI, bias, regulation', 15, 4),
(24, 3, 'Final Year Project', 'Capstone project', 30, 4),
(25, 4, 'Financial Accounting', 'Double entry, financial statements', 15, 1),
(26, 4, 'Management Accounting', 'Budgeting, costing, variance analysis', 15, 1),
(27, 4, 'Business Law', 'Contract law, company law', 15, 2),
(28, 4, 'Taxation', 'Income tax, VAT, corporate tax', 15, 2),
(29, 4, 'Auditing', 'Internal and external audit principles', 15, 3),
(30, 4, 'Financial Management', 'Investment appraisal, working capital', 15, 3),
(31, 4, 'Economics', 'Micro and macroeconomics', 15, 4),
(32, 4, 'Final Year Project', 'Capstone project', 30, 4),
(33, 1, 'Artificial Intelligence', 'AI fundamentals and applications', 15, 5),
(34, 1, 'Mobile Development', 'Android and iOS development', 15, 5),
(35, 1, 'Cloud Computing', 'AWS, Azure, cloud architecture', 15, 6),
(36, 1, 'Capstone Project', 'Final year capstone', 30, 6),
(37, 2, 'Network Automation', 'Python for network automation', 15, 5),
(38, 2, 'IoT Networks', 'Internet of Things networking', 15, 5),
(39, 2, 'Advanced Security', 'Advanced cybersecurity topics', 15, 6),
(40, 2, 'Capstone Project', 'Final year capstone', 30, 6),
(41, 3, 'Reinforcement Learning', 'RL algorithms and applications', 15, 5),
(42, 3, 'AI in Healthcare', 'Medical AI applications', 15, 5),
(43, 3, 'Generative AI', 'GANs, diffusion models, LLMs', 15, 6),
(44, 3, 'Capstone Project', 'Final year capstone', 30, 6),
(45, 4, 'Advanced Taxation', 'International tax, transfer pricing', 15, 5),
(46, 4, 'Corporate Finance', 'M&A, capital structure, valuation', 15, 5),
(47, 4, 'Financial Reporting', 'IFRS, consolidation, disclosures', 15, 6),
(48, 4, 'Capstone Project', 'Final year capstone', 30, 6);

-- --------------------------------------------------------

--
-- Table structure for table `Notes`
--

CREATE TABLE `Notes` (
  `note_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `note_title` varchar(200) DEFAULT NULL,
  `note_content` text NOT NULL,
  `note_created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Notes`
--

INSERT INTO `Notes` (`note_id`, `student_id`, `note_title`, `note_content`, `note_created_at`) VALUES
(1, 10, 'test', 'test123', '2026-05-20 22:57:01'),
(2, 10, '123', 'sas', '2026-05-21 04:08:22');

-- --------------------------------------------------------

--
-- Table structure for table `Schedule`
--

CREATE TABLE `Schedule` (
  `schedule_id` int(11) NOT NULL,
  `section_id` varchar(20) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `day` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Schedule`
--

INSERT INTO `Schedule` (`schedule_id`, `section_id`, `module_id`, `day`, `start_time`, `end_time`) VALUES
(8, 'AI1', 22, 'Sunday', '06:00:00', '07:00:00'),
(9, 'AI1', 21, 'Sunday', '08:00:00', '09:00:00'),
(10, 'AI1', 22, 'Monday', '10:30:00', '11:30:00'),
(11, 'AI1', 21, 'Monday', '12:30:00', '13:30:00'),
(12, 'AI1', 22, 'Tuesday', '10:30:00', '12:00:00'),
(13, 'AI1', 21, 'Tuesday', '13:30:00', '14:30:00'),
(14, 'AI1', 22, 'Thursday', '09:00:00', '11:00:00'),
(15, 'AI1', 21, 'Thursday', '12:00:00', '14:00:00'),
(18, 'C4', 8, 'Sunday', '06:00:00', '07:00:00'),
(19, 'C4', 8, 'Sunday', '08:00:00', '09:00:00'),
(20, 'AI2', 38, 'Sunday', '06:00:00', '06:30:00'),
(30, 'AF2', 32, 'Sunday', '07:00:00', '08:00:00'),
(31, 'AF2', 31, 'Sunday', '08:00:00', '09:00:00'),
(32, 'AF2', 32, 'Wednesday', '06:30:00', '07:30:00'),
(33, 'AF2', 31, 'Wednesday', '08:00:00', '09:00:00'),
(34, 'AF2', 32, 'Thursday', '07:00:00', '09:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `Section`
--

CREATE TABLE `Section` (
  `section_id` varchar(20) NOT NULL,
  `section_name` varchar(20) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Section`
--

INSERT INTO `Section` (`section_id`, `section_name`, `faculty_id`) VALUES
('AF1', 'AF1', 4),
('AF2', 'AF2', 4),
('AF3', 'AF3', 4),
('AF4', 'AF4', 4),
('AI1', 'AI1', 3),
('AI2', 'AI2', 3),
('AI3', 'AI3', 3),
('AI4', 'AI4', 3),
('C1', 'C1', 1),
('C2', 'C2', 1),
('C3', 'C3', 1),
('C4', 'C4', 1),
('N1', 'N1', 2),
('N2', 'N2', 2),
('N3', 'N3', 2),
('N4', 'N4', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(35) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `password` varchar(255) NOT NULL,
  `grade_level` varchar(20) DEFAULT NULL,
  `faculty_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1,
  `section_id` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'APPROVED'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `email`, `phone`, `password`, `grade_level`, `faculty_id`, `image`, `admin_id`, `section_id`, `status`) VALUES
(5, 'Shine', 'Amgain', '2026-05-06', 'Male', 'shineamg@gmail.com', '9813531101', '$2a$10$Zs1hHLH4Tb2jl7yquSNalOtWu8wPHFdI2VS/.sCdNXV3tOj3kvQV2', NULL, 1, 'uploads/Screenshot 2026-05-04 at 5.41.34 pm.png', 1, NULL, 'APPROVED'),
(6, 'Shine', 'Amgain', '2026-05-06', 'Female', 'shineamgain@gmail.com', '9813531101', '$2a$10$U6Wn.D0AjjWdoP8PnC3rd.lWMwoOOVLdpznScQOdO26r9yd7UFpoy', NULL, 3, 'uploads/Screenshot 2026-05-04 at 5.41.34 pm.png', 1, NULL, 'REJECTED'),
(8, 'Shine', 'Amgain', '2026-05-01', 'Female', 'shine@gmail.com', '+9779813531101', '$2a$10$fMfNCGnFwusuCe5YAWT/3.8v86UMIsyHknXSo4h.2rmj1mSCJ6H8m', NULL, 1, 'uploads/sciptlogo.svg', 1, NULL, 'APPROVED'),
(9, 'shai', 'shai', '2026-05-29', 'Female', 'shai@gmail.com', '', '$2a$10$IXF7MLBm3dgJJc952fLniOdPy3bvxUQUJ2uAOAjJZFJ18AY8NhPYa', NULL, 4, 'uploads/brit.png', 1, NULL, 'APPROVED'),
(10, 'Shai', 'Amgain', '2026-05-14', 'Female', 'shi@gmail.com', '+9779813531101', '$2a$10$cEo9frx5q7NBo03J1gNYBONxsfZ.3jgJ7Ml1SDjYNhdQYldmJPaMW', 'Semester 4', 4, 'uploads/profiles/5c6e4d2c-8fce-4a00-8f34-9ad4b2e7f51b.jpg', 1, 'AF2', 'APPROVED'),
(11, 'shine', 'Amgain', '2026-04-30', 'Female', 'suzzuamgain@hotmail.com', '+9779841516555', '$2a$10$Ay1T24GyibgPXwqCs3rZluKO71ja4F6gTr0w19B489PaW4AP2lJHi', '2', 3, 'uploads/profiles/a1593b4f-82b4-4bb8-bd44-b1a6dfba34c3.png', 1, 'AI3', 'APPROVED'),
(12, 'Durga', 'Amgain', '2026-05-21', 'Male', 'me@gmail.com', '+9779841516555', '$2a$10$1Lv.LQbaQzyoytHEUIE6eexs353y95O/XWO0uvUOafYtYqPT3kbEW', '2', 3, 'uploads/profiles/49e5b195-b54f-43dd-a6fb-8892fbad7693.jpg', 1, 'N1', 'APPROVED'),
(13, 'subu', 'Amgain', '2026-05-20', 'Female', 'subu@gmail.com', '+9779813531101', '$2a$10$WuIsJXO7dlYEt7yv6/SrP.mcE8y94FEqTRt/de7Hkl0WQIQ4SSMyu', '1', 3, 'uploads/profiles/default.png', 1, 'AI1', 'REJECTED'),
(14, 'sabi', 'pandey', '2026-05-26', 'Female', 'sabi@gmail.com', '+9779841516555', '$2a$10$i9HF429KM5Bw2R4NMHrNFup2hNTC7JjnIEWfNofhmQ0VzrFm6X4fK', '1', 3, 'uploads/profiles/624cc9ad-3049-4793-b57b-45fca4fdd825.png', 1, 'AI4', 'APPROVED'),
(15, 'nish', 'riti', '2026-05-27', 'Female', 'nish@gmail.com', '9813531101', '$2a$10$bfkYgoLr9HsVdZlXWbzlguJ9Sm8oZDXCdOQn4yQmuOk75ZyeKYWPi', '2', 3, 'uploads/profiles/49533e9b-8b28-4e8e-9e2e-1e8d2ad71fb7.jpg', 1, 'AI1', 'APPROVED'),
(16, 'Kusum', 'Kiju', '2007-06-05', 'Female', 'kusum@gmail.com', '+9779841516555', '$2a$10$rpDWWrmyJeza/k/6HX.PgeQS4VSupG.Khbr9wfN8h7nbU6wfiY8Ri', '4', 1, 'uploads/profiles/default.png', 1, 'C4', 'REJECTED'),
(17, 'Kusum', 'Kiju', '2007-06-05', 'Female', 'kusumkiju@gmail.com', '+9779841516555', '$2a$10$DJ7tlcRiA7tVwFYMU36H1ullhbIBXqBl5CAhvBxDzbMD4CNchC8Km', '4', 1, 'uploads/profiles/e8ac509b-bb21-40b3-9043-acb5c6216723.jpg', 1, 'C4', 'APPROVED'),
(18, 'Dilisha', 'Kiju', '2007-06-05', 'Female', 'dilisha@gmail.com', '+9779841516555', '$2a$10$Bn5vuTe3NiT/G9MnF3a79OUlL5TmafFPoH1YGdIuZRi8RHzv9tmQS', '4', 1, 'uploads/profiles/1b03c7c4-34b4-4ad6-a40f-957a8cd4bff8.gif', 1, 'C4', 'REJECTED'),
(19, 'Dilisha', 'Kiju', '2007-06-05', 'Female', 'dilishagurung@gmail.com', '+9779841516555', '$2a$10$siLKaPFwuVM3qLS/tg5X2.4Xac0lnWH5VBrAXTpvF1HkPDvHJALGy', '4', 1, 'uploads/profiles/34e3ce19-d3aa-457d-94e2-539cde416ebf.gif', 1, 'C4', 'APPROVED'),
(20, 'Nishriti', 'Tamrakar', '2006-05-07', 'Female', 'nishriti@gmail.com', '+9779860945874', '$2a$10$TFH.kXafTZE858CWfbu2P.4mRyv9BZT03f9ERxun4JBcCgukwOwC6', '4', 1, 'uploads/profiles/a0aa3966-e39a-4a6d-84b8-c352ff72997e.gif', 1, 'C4', 'PENDING'),
(21, 'Suzzine', 'Amgain', '2026-05-20', 'Female', 'suzzu@hotmail.com', '+9779860945874', '$2a$10$X1ZYq3S046h0cOZBEPZ6Qe.XOFjscT67xzEmuW.tnepvZZFDfe.hu', 'Semester 2', 1, 'uploads/profiles/default.png', 1, 'C1', 'APPROVED'),
(22, 'Suzzu', 'Amgain', '2026-05-03', 'Female', 'suzzu@gmail.com', '+9779860945874', '$2a$10$q14oPP.Ql5IldqKJnWFlne2iwuZz5UsExtPfl6d8lH/XHDOkBiX2m', '1', 1, 'uploads/profiles/557338f6-38a3-4288-8089-dae59286afc0.jpeg', 1, 'C1', 'PENDING');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `Announcement`
--
ALTER TABLE `Announcement`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `fk_announcement_admin` (`admin_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `ClassReservation`
--
ALTER TABLE `ClassReservation`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `fk_reservation_class` (`class_id`);

--
-- Indexes for table `Faculty`
--
ALTER TABLE `Faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `Module`
--
ALTER TABLE `Module`
  ADD PRIMARY KEY (`module_id`),
  ADD KEY `fk_module_faculty` (`faculty_id`);

--
-- Indexes for table `Notes`
--
ALTER TABLE `Notes`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `fk_notes_student` (`student_id`);

--
-- Indexes for table `Schedule`
--
ALTER TABLE `Schedule`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `section_id` (`section_id`),
  ADD KEY `module_id` (`module_id`);

--
-- Indexes for table `Section`
--
ALTER TABLE `Section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `fk_section_faculty` (`faculty_id`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_student_admin` (`admin_id`),
  ADD KEY `fk_student_faculty` (`faculty_id`),
  ADD KEY `fk_student_section` (`section_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Admin`
--
ALTER TABLE `Admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Announcement`
--
ALTER TABLE `Announcement`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ClassReservation`
--
ALTER TABLE `ClassReservation`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Faculty`
--
ALTER TABLE `Faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Module`
--
ALTER TABLE `Module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `Notes`
--
ALTER TABLE `Notes`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Schedule`
--
ALTER TABLE `Schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `Student`
--
ALTER TABLE `Student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Announcement`
--
ALTER TABLE `Announcement`
  ADD CONSTRAINT `fk_announcement_admin` FOREIGN KEY (`admin_id`) REFERENCES `Admin` (`admin_id`);

--
-- Constraints for table `ClassReservation`
--
ALTER TABLE `ClassReservation`
  ADD CONSTRAINT `fk_classreservation_student` FOREIGN KEY (`student_id`) REFERENCES `Student` (`student_id`),
  ADD CONSTRAINT `fk_reservation_class` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Module`
--
ALTER TABLE `Module`
  ADD CONSTRAINT `fk_module_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `Faculty` (`faculty_id`);

--
-- Constraints for table `Notes`
--
ALTER TABLE `Notes`
  ADD CONSTRAINT `fk_notes_student` FOREIGN KEY (`student_id`) REFERENCES `Student` (`student_id`);

--
-- Constraints for table `Schedule`
--
ALTER TABLE `Schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `Section` (`section_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `Module` (`module_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Section`
--
ALTER TABLE `Section`
  ADD CONSTRAINT `fk_section_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `Faculty` (`faculty_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Student`
--
ALTER TABLE `Student`
  ADD CONSTRAINT `fk_student_admin` FOREIGN KEY (`admin_id`) REFERENCES `Admin` (`admin_id`),
  ADD CONSTRAINT `fk_student_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `Faculty` (`faculty_id`),
  ADD CONSTRAINT `fk_student_section` FOREIGN KEY (`section_id`) REFERENCES `Section` (`section_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
